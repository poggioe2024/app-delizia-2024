﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos
{
    public class DLogin
    {
        public bool checkCredenciales(string cedula, string contrasena)
        {
            Conexion conexion = new Conexion();
            conexion.getConexion();
            string resultado = conexion.consulta("SELECT cedula FROM funcionarios WHERE cedula=" + cedula);
            conexion.cerrarConexion();
            if (resultado != null)
            {
                return checkPass(cedula, contrasena);
            }
            else
            {
                return false;
            }
        }
        public bool checkPass(string cedula, string contrasena)
        {
            Conexion conexion = new Conexion();
            conexion.getConexion();
            string resultado = conexion.consulta("SELECT contrasena FROM funcionarios WHERE cedula=" + cedula);
            conexion.cerrarConexion();
            if ((resultado != null))
            {
                if (contrasena == resultado)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }
        public int getRol(string cedula)
        {
            Conexion conexion = new Conexion();
            conexion.getConexion();
            string resultado = conexion.consulta("SELECT rol FROM funcionarios WHERE cedula=" + cedula);
            conexion.cerrarConexion();
            return int.Parse(resultado);
        }
    }
}
