﻿using MySql.Data.MySqlClient;

namespace Datos
{
    public class Conexion
    {
        private MySqlConnection conexion;
        private string server = "localhost";
        private string database = "delizia_bd";
        private string user = "admin-user";
        private string password = "k9Ph4W8/3pG-yn5H"; // para encriptar a futuro
        private string cadena_conexion;

        public Conexion()
        {
            cadena_conexion = "Database=" + database +
                "; DataSource=" + server +
                "; User Id=" + user +
                "; Password=" + password;
        }

        public MySqlConnection getConexion()
        {
            if (conexion == null)
            {
                conexion = new MySqlConnection(cadena_conexion);
                conexion.Open();
            }
            return conexion;
        }
        public string consulta(string consulta)
        {
            List<string> resultados = new List<string>();
            MySqlDataReader mySqlDataReader = null;

            if (conexion != null)
            {
                MySqlCommand mySqlCommand = new MySqlCommand(consulta);
                mySqlCommand.Connection = getConexion();
                mySqlDataReader = mySqlCommand.ExecuteReader();

                while (mySqlDataReader.Read())
                {
                    List<string> valores_columnas = new List<string>();

                    for (int i = 0; i < mySqlDataReader.FieldCount; i++)
                    {
                        valores_columnas.Add(mySqlDataReader[i].ToString());
                    }

                    resultados.Add(string.Join(", ", valores_columnas));
                }

                mySqlDataReader.Close();
            }

            return string.Join(", ", resultados);
        }

        public void insercion(string cadena)
        {
            if (conexion != null)
            {
                MySqlCommand mySqlCommand = new MySqlCommand(cadena);
                mySqlCommand.Connection = getConexion();
                int filas_afectadas = mySqlCommand.ExecuteNonQuery();
            }
        }

        public void cerrarConexion()
        {
            if (conexion != null) {
                conexion.Close();
            }
        }

        //  SELECT p.*, pp.producto_id, pp.cantidad
        //  FROM pedidos AS p
        //  INNER JOIN pedidosproductos AS pp ON p.id = pp.pedido_id; 

    }
}
