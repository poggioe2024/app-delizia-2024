﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos
{
    public class DCocina
    {
        public string getIdPedidos()
        {
            List<int> ids = new List<int>();
            Conexion conexion = new Conexion();
            conexion.getConexion();
            string resultado = conexion.consulta("SELECT (id) FROM pedidos where estado=1");
            /**string[] idStrings = resultado.Split(new[] { ", " }, StringSplitOptions.RemoveEmptyEntries);

            foreach (string id in idStrings)
            {
                if (int.TryParse(id, out int idParsed))
                {
                    ids.Add(idParsed);
                }
            }
            conexion.cerrarConexion();
            return ids;**/
            return resultado;
        }
        public string getPedido(int id)
        {
            Conexion conexion = new Conexion();
            conexion.getConexion();
            string resultado = conexion.consulta("SELECT * FROM pedidos where id=" + id);
            return resultado;
        }
        public string getIdProductos(int idPedido)
        {
            List<int> ids = new List<int>();
            Conexion conexion = new Conexion();
            conexion.getConexion();
            string resultado = conexion.consulta("SELECT id_producto, cantidad FROM pedidosproductos where id_pedido=" + idPedido);
            return resultado;
        }
        public string getProducto(int id)
        {
            Conexion conexion = new Conexion();
            conexion.getConexion();
            string resultado = conexion.consulta("SELECT * FROM productos WHERE id=" + id);
            conexion.cerrarConexion();
            return resultado;
        }
    }
}
