﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos
{
    class dCrud
    {
        private String tabla = "";
        private String[] datos = new String[] { };
        private String[] datos_rel = new String[] { };
        private int consultaTipo = 0;

        // en caso de editar
        private string sujeto = "";
        private int idSujeto = 0;

        private String GenerarConsulta(dCrud crud) {
            String salida = "";
            switch (consultaTipo)
            {
                case 1: // agrega
                    salida = String.Format("INSERT INTO {0}", tabla);
                    for (int i = 0; i < datos.Length; i++) {
                        if (i == 0) {
                            salida += "(";
                        }
                        salida += datos[i];
                        if (i < datos.Length - 1) {
                            salida += ") VALUES (";
                        }
                    }
                    break;
                case 2: // quita
                    salida = String.Format("DELETE FROM {0} WHERE", tabla);
                    break;
                case 3: // edita
                    salida = String.Format("UPDATE {0} SET", tabla);
                    salida += salida = String.Format("WHERE {0}={1}", sujeto, idSujeto.ToString());
                    break;
                case 4:
                    salida = String.Format("SELECT * FROM {0} WHERE {1}={2}", tabla, sujeto, idSujeto.ToString());
                    break;
                case 5:
                    break;
                default:
                    salida = "ERROR";
                    break;
            }
            return salida;
        }
    }
}
