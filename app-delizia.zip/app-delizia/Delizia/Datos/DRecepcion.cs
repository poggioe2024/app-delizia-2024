﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Mysqlx.Crud;
using Mysqlx.Cursor;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Datos
{
    public class DRecepcion
    {
        public DRecepcion() { }
        public int getCantidadProductos()
        {
            Conexion conexion = new Conexion();
            conexion.getConexion();
            string resultado = conexion.consulta("SELECT COUNT(*) FROM productos");
            conexion.cerrarConexion();
            return int.Parse(resultado);
        }

        public string getProducto(int id)
        {
            Conexion conexion = new Conexion();
            conexion.getConexion();
            string resultado = conexion.consulta("SELECT * FROM productos WHERE id=" + id);
            conexion.cerrarConexion();
            return resultado;
        }
        public void crearPedido(DateOnly fecha, TimeOnly hora, double precio, int estado, int cajero, string nombre, string telefono, string calle1, string calle2, int numeroPuerta, string detalle, List<int> productosId, List<int> productosCantidad)
        {
            Conexion conexion = new Conexion();
            conexion.getConexion();
            string cadena = "INSERT INTO pedidos(fecha, hora, precio, estado, cajero, nombre, telefono, calle_1, calle_2, numero_puerta, detalle) VALUES ('" + fecha.ToString("yyyy-MM-dd") + "','" + hora + "','" + precio + "','" + estado + "','" + cajero + "','" + nombre + "','" + telefono + "','" + calle1 + "','" + calle2 + "','" + numeroPuerta + "','" + detalle + "');";
            conexion.insercion(cadena);
            conexion.cerrarConexion();

            int idPedido = obtenerIdPedido(fecha, hora);

            for (int index = 0; index < productosId.Count; index++)
            {
                insertarPedidoProducto(idPedido, productosCantidad[index], productosId[index]);
            }
        }

        public int obtenerIdPedido(DateOnly fecha, TimeOnly hora)
        {
            Conexion conexion = new Conexion();
            conexion.getConexion();
            string cadena = "SELECT id FROM pedidos WHERE fecha='" + fecha.ToString("yyyy-MM-dd") + "' AND hora ='" + hora + "';";
            int idPedido = int.Parse(conexion.consulta(cadena));
            conexion.cerrarConexion();
            return idPedido;
        }
        public void insertarPedidoProducto(int idPedido, int cantidad, int idProducto)
        {
            Conexion conexion = new Conexion();
            conexion.getConexion();
            string cadena = "INSERT INTO pedidosproductos(id_pedido, id_producto, cantidad) VALUES ('" + idPedido + "','" + idProducto + "','" + cantidad + "');";
            conexion.insercion(cadena);
            conexion.cerrarConexion();
        }

    }
}