﻿using Datos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logica
{
    public class LCocina
    {
        public string prueba(List<int> ids)
        {
            DCocina d = new DCocina();
            return "";
        }
        public List<Pedido> obtenerPedidos(List<int> ids)
        {
            List<Pedido> pedidos = new List<Pedido>();
            DCocina d = new DCocina();
            string n ="";
            foreach (int id in ids) {
                string productoString = d.getPedido(id);
                n = productoString;
                Pedido p = procesarPedido(productoString);
                p.Productos = modificarProductos(p.id);
                pedidos.Add(p);
            }
            return pedidos;
        }
        public Pedido procesarPedido(string pedidoString)
        {
            List<string> l = new List<string>(pedidoString.Split(new string[] { ", " }, StringSplitOptions.None));
            string n = l[1];
            n = new List<string>(n.Split(" ", StringSplitOptions.None))[0];
            Pedido pedido = new Pedido(null, int.Parse(l[0]), DateOnly.Parse(n), TimeOnly.Parse(l[2]), double.Parse(l[3]), int.Parse(l[4]), int.Parse(l[7]), -1, -1, l[9], l[10], l[11], "", int.Parse(l[14]), l[14]);
            return pedido;
        }
        public Producto procesarProducto(string productoString)
        {
            List<string> lista = new List<string>(productoString.Split(new string[] { ", " }, StringSplitOptions.None));
            Producto producto = new Producto(int.Parse(lista[0]), lista[1], double.Parse(lista[2]), lista[3], int.Parse(lista[4]), 0);
            return producto;
        }
        public List<Producto> modificarProductos(int idPedido)
        {
            DCocina d = new DCocina();

            List<Producto> productos = new List<Producto>();
            string idPedidosString = d.getIdProductos(idPedido);

            List<string> l = new List<string>(idPedidosString.Split(new string[] { ", " }, StringSplitOptions.None));

            List<int> ids = new List<int>();
            List<int> cantidades = new List<int>();

            int verificador = 0;
            for (int i = 0; i<l.Count; i++)
            {
                if (verificador == 0)
                {
                    ids.Add(int.Parse(l[i]));
                    verificador = 1;
                }
                else
                {
                    cantidades.Add(int.Parse(l[i]));
                    verificador = 0;
                }
            }
            
            for (int i = 0; i<ids.Count; i++)
            {
                string productoString = d.getProducto(ids[i]);
                Producto p = procesarProducto(productoString);
                p.Cantidad = cantidades[i];
                productos.Add(p);
            }

            return productos;
        }
    }
}
