﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logica
{
    public class Pedido
    {
        public int id { get; set; }
        public DateOnly fecha { get; set; }
        public TimeOnly hora { get; set; }
        public double precio { get; set; }
        public int estado { get; set; }
        public int registrado { get; set; }
        public int cliente { get; set; }
        public int cajero { get; set; }
        public int cocinero { get; set; }
        public int repartidor { get; set; }
        public string nombre { get; set; }
        public string telefono { get; set; }
        public string calle1 { get; set; }
        public string calle2 { get; set; }
        public int numeroPuerta { get; set; }
        public string detalle { get; set; }
        public List<Producto> Productos { get; set; }
        public Pedido(List<Producto> productos, int id, DateOnly fecha, TimeOnly hora, double precio, int estado, int cajero, int cocinero, int repartidor, string nombre, string telefono, string calle1, string calle2, int numeroPuerta, string detalle) {
            this.id = id;
            this.fecha = fecha;
            this.hora = hora;
            this.precio = precio;
            this.estado = estado;
            this.cajero = cajero;
            this.cocinero = cocinero;
            this.repartidor = repartidor;
            this.nombre = nombre;
            this.telefono = telefono;
            this.calle1 = calle1;
            this.calle2 = calle2;
            this.numeroPuerta = numeroPuerta;
            this.detalle = detalle;
            this.Productos = productos;
        }
    }
}