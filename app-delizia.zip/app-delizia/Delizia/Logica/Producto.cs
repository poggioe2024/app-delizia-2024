﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logica
{
    public class Producto
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public double Precio { get; set; }
        public string Descripcion { get; set; }
        public int Tipo { get; set; }
        public int Cantidad { get; set; }

        public Producto(int id, string nombre, double precio, string descripcion, int tipo, int cantidad)
        {
            Id = id;
            Nombre = nombre;
            Precio = precio;
            Descripcion = descripcion;
            Tipo = tipo;
            Cantidad = cantidad;
        }
    }

}
