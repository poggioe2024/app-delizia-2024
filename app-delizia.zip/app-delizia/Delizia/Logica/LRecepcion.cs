﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Datos;
using Mysqlx.Cursor;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Logica
{
    public class LRecepcion
    {
        DRecepcion dRecepcion;
        public LRecepcion() {
            dRecepcion = new DRecepcion();
        }

        public List<Producto> obtenerProductos()
        {
            List<Producto> productos = new List<Producto>();
            int cantidadProductos = dRecepcion.getCantidadProductos();
            for (int i = 1; i <= cantidadProductos; i++) {
                string productoString = dRecepcion.getProducto(i);
                productos.Add(procesarProducto(productoString));
            }
            return productos;
        }

        public Producto procesarProducto(string productoString) {
            List<string> lista = new List<string>(productoString.Split(new string[] { ", " }, StringSplitOptions.None));
            Producto producto = new Producto(int.Parse(lista[0]), lista[1], double.Parse(lista[2]), lista[3], int.Parse(lista[4]), 0);
            return producto;
        }

        public Pedido crearPedido(List<Producto> productos, int id, DateOnly fecha, TimeOnly hora, double precio, int estado, int cajero, int cocinero, int repartidor, string nombre, string telefono, string calle1, string calle2, int numeroPuerta, string detalle)
        {
            /**
            this.id = id;   this.precio = precio;
            this.fecha = fecha; this.estado = estado;
            this.hora = hora;   this.cajero = cajero;
            this.cocinero = cocinero;   this.telefono = telefono;
            this.repartidor = repartidor;   this.calle1 = calle1;
            this.nombre = nombre;   this.calle2 = calle2;
            this.numeroPuerta = numeroPuerta;
            this.detalle = detalle;
            this.Productos = productos;
            **/
            Pedido pedido = new Pedido(productos, id, fecha, hora, precio, estado, cajero, cocinero, repartidor, nombre, telefono, calle1, calle2, numeroPuerta, detalle);
            return pedido;
        }
    }
}
