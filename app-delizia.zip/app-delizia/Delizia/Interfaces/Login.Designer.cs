﻿using System.Drawing.Text;

namespace Interfaces
{
    partial class Login
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        PrivateFontCollection customFonts = new PrivateFontCollection();

        private void LoadCustomFont()
        {
            string fontPath = Path.Combine(Application.StartupPath, @"img\OpenDyslexic-Regular.otf");

            customFonts.AddFontFile(fontPath);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            panelPrincipal = new Panel();
            labelContrasena = new Label();
            labelDocumento = new Label();
            txtDocumento = new TextBox();
            txtContrasena = new TextBox();
            botonBorrar = new Button();
            botonIngresar = new Button();
            panelPrincipal.SuspendLayout();
            SuspendLayout();
            // 
            // panelPrincipal
            // 
            panelPrincipal.BackColor = Color.FromArgb(30, 30, 36);
            panelPrincipal.BorderStyle = BorderStyle.FixedSingle;
            panelPrincipal.Controls.Add(labelContrasena);
            panelPrincipal.Controls.Add(labelDocumento);
            panelPrincipal.Controls.Add(txtDocumento);
            panelPrincipal.Controls.Add(txtContrasena);
            panelPrincipal.Controls.Add(botonBorrar);
            panelPrincipal.Controls.Add(botonIngresar);
            panelPrincipal.Location = new Point(50, 50);
            panelPrincipal.Name = "panelPrincipal";
            panelPrincipal.Size = new Size(300, 500);
            panelPrincipal.TabIndex = 0;
            // 
            // labelContrasena
            // 
            labelContrasena.AutoSize = true;
            labelContrasena.Font = new Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelContrasena.ForeColor = Color.FromArgb(247, 243, 227);
            labelContrasena.Location = new Point(25, 214);
            labelContrasena.Name = "labelContrasena";
            labelContrasena.Size = new Size(118, 28);
            labelContrasena.TabIndex = 5;
            labelContrasena.Text = "Contraseña";
            // 
            // labelDocumento
            // 
            labelDocumento.AutoSize = true;
            labelDocumento.Font = new Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelDocumento.ForeColor = Color.FromArgb(247, 243, 227);
            labelDocumento.Location = new Point(25, 121);
            labelDocumento.Name = "labelDocumento";
            labelDocumento.Size = new Size(122, 28);
            labelDocumento.TabIndex = 4;
            labelDocumento.Text = "Documento";
            // 
            // txtDocumento
            // 
            txtDocumento.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtDocumento.Location = new Point(20, 152);
            txtDocumento.Name = "txtDocumento";
            txtDocumento.Size = new Size(200, 29);
            txtDocumento.TabIndex = 3;
            txtDocumento.TextChanged += txtDocumento_TextChanged;
            // 
            // txtContrasena
            // 
            txtContrasena.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtContrasena.Location = new Point(20, 245);
            txtContrasena.Name = "txtContrasena";
            txtContrasena.PasswordChar = '•';
            txtContrasena.Size = new Size(200, 29);
            txtContrasena.TabIndex = 2;
            txtContrasena.UseSystemPasswordChar = true;
            // 
            // botonBorrar
            // 
            botonBorrar.BackColor = Color.FromArgb(218, 44, 56);
            botonBorrar.FlatStyle = FlatStyle.Popup;
            botonBorrar.Image = (Image)resources.GetObject("botonBorrar.Image");
            botonBorrar.Location = new Point(15, 435);
            botonBorrar.Name = "botonBorrar";
            botonBorrar.Size = new Size(45, 45);
            botonBorrar.TabIndex = 1;
            botonBorrar.UseVisualStyleBackColor = false;
            botonBorrar.Click += botonBorrar_Click;
            // 
            // botonIngresar
            // 
            botonIngresar.BackColor = Color.FromArgb(83, 165, 72);
            botonIngresar.FlatStyle = FlatStyle.Popup;
            botonIngresar.Font = new Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point, 0);
            botonIngresar.ForeColor = Color.FromArgb(247, 243, 227);
            botonIngresar.Location = new Point(80, 435);
            botonIngresar.Name = "botonIngresar";
            botonIngresar.RightToLeft = RightToLeft.No;
            botonIngresar.Size = new Size(200, 45);
            botonIngresar.TabIndex = 0;
            botonIngresar.Text = "Ingresar";
            botonIngresar.UseVisualStyleBackColor = false;
            botonIngresar.Click += botonIngresar_Click;
            // 
            // Login
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.fondo;
            Controls.Add(panelPrincipal);
            Name = "Login";
            Size = new Size(800, 600);
            panelPrincipal.ResumeLayout(false);
            panelPrincipal.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panelPrincipal;
        private Label labelContrasena;
        private Label labelDocumento;
        private TextBox txtDocumento;
        private TextBox txtContrasena;
        private Button botonBorrar;
        private Button botonIngresar;
    }

    

}
