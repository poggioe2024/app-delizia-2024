﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Datos;
using Logica;

namespace Interfaces
{
    public partial class RecepcionProducto : UserControl
    {
        Producto producto { get; set; }
        public RecepcionProducto(Producto producto)
        {
            InitializeComponent();
            DProducto dProducto = new DProducto();
            this.producto = producto;
        }

        public Producto getProducto()
        {
            return this.producto;
        }

        public void setValores()
        {
            labelNombre.Text = "" + producto.Nombre;
            labelPrecio.Text = "$" + producto.Precio;
            imagenProducto.ImageLocation = "C:\\Program Files\\Delizia\\img\\" + producto.Id + ".png";
            labelId.Text = "" + producto.Id;
        }

        private void botonQuitar_Click(object sender, EventArgs e)
        {
            int cantidad = int.Parse(labelCantidad.Text);
            if (cantidad > 0)
            {
                cantidad--;
            }
            producto.Cantidad = cantidad;
            labelCantidad.Text = "" + cantidad;
        }

        private void botonAgregar_Click(object sender, EventArgs e)
        {
            int cantidad = int.Parse(labelCantidad.Text);
            cantidad++;
            producto.Cantidad = cantidad;
            labelCantidad.Text = "" + cantidad;
        }
    }
}
