﻿using Logica;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Interfaces
{
    public partial class RecepcionConfirmacionProducto : UserControl
    {
        Producto producto;
        public RecepcionConfirmacionProducto(Producto producto)
        {
            InitializeComponent();
            this.producto = producto;
        }
        public void setValores()
        {
            this.labelCantidad.Text = "" + producto.Cantidad;
            this.labelProducto.Text = "" + producto.Nombre;
            this.labelPrecio.Text = "$" + (producto.Precio * producto.Cantidad);
        }
    }
}
