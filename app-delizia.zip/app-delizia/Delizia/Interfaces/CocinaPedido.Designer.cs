﻿namespace Interfaces
{
    partial class CocinaPedido
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            labelId = new Label();
            panelProductos = new Panel();
            botonEstado = new Button();
            SuspendLayout();
            // 
            // labelId
            // 
            labelId.Font = new Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelId.Location = new Point(10, 3);
            labelId.Name = "labelId";
            labelId.Size = new Size(180, 32);
            labelId.TabIndex = 13;
            labelId.Text = "0";
            labelId.TextAlign = ContentAlignment.TopCenter;
            // 
            // panelProductos
            // 
            panelProductos.AutoScroll = true;
            panelProductos.Location = new Point(5, 38);
            panelProductos.Name = "panelProductos";
            panelProductos.Size = new Size(190, 165);
            panelProductos.TabIndex = 14;
            // 
            // botonEstado
            // 
            botonEstado.BackColor = Color.FromArgb(83, 165, 72);
            botonEstado.FlatStyle = FlatStyle.Popup;
            botonEstado.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            botonEstado.ForeColor = Color.FromArgb(247, 243, 227);
            botonEstado.Location = new Point(50, 210);
            botonEstado.Name = "botonEstado";
            botonEstado.Size = new Size(100, 35);
            botonEstado.TabIndex = 15;
            botonEstado.Text = "Confirmar";
            botonEstado.UseVisualStyleBackColor = false;
            botonEstado.Click += botonEstado_Click;
            // 
            // CocinaPedido
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(247, 243, 227);
            BorderStyle = BorderStyle.FixedSingle;
            Controls.Add(botonEstado);
            Controls.Add(panelProductos);
            Controls.Add(labelId);
            Name = "CocinaPedido";
            Size = new Size(198, 248);
            ResumeLayout(false);
        }

        #endregion

        private Label labelId;
        private Panel panelProductos;
        private Button botonEstado;
    }
}
