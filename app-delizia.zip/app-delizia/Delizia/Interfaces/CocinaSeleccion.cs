﻿using Datos;
using Logica;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Interfaces
{
    public partial class CocinaSeleccion : UserControl
    {
        App parent;
        int documento;
        public CocinaSeleccion(App parent, int documento)
        {
            InitializeComponent();
            this.parent = parent;
            this.documento = documento;
            /**LCocina l = new LCocina();
            MessageBox.Show("" +
            l.prueba(getIds()), "datos");
            **/
            mostrarPedidos();
        }

        private void botonCancelar_Click(object sender, EventArgs e)
        {
            CocinaMenu m = new CocinaMenu(parent, documento);
            parent.Controls.Add(m);
            parent.Controls.Remove(this);
        }

        public void mostrarPedidos()
        {
            LCocina l = new LCocina();
            List<int> ids = getIds();
            List<Pedido> pedidos = l.obtenerPedidos(ids);
            int num = 1;
            int x = 10;
            int y = 20;
            foreach (Pedido pedido in pedidos)
            {
                CocinaPedido cocinaPedido = new CocinaPedido(pedido);
                // cocinaPedido.setValores();
                this.panelPedidos.Controls.Add((Control)cocinaPedido);
                cocinaPedido.Location = new Point(x, y);
                if (num % 3 == 0)
                {
                    x = 10;
                    y += 270;
                }
                else
                    x += 220;
                ++num;
            }
        }

        private List<int> getIds()
        {
            DCocina d = new DCocina();
            string idPedidosString = d.getIdPedidos();
            List<string> lista = new List<string>(idPedidosString.Split(new string[] { ", " }, StringSplitOptions.None));
            List<int> ids = new List<int>();
            foreach (string id in lista)
            {
                ids.Add(int.Parse(id));
            }
            return ids;
        }
    }
}
