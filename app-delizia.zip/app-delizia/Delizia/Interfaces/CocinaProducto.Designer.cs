﻿namespace Interfaces
{
    partial class CocinaProducto
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            labelProducto = new Label();
            labelCantidad = new Label();
            SuspendLayout();
            // 
            // labelProducto
            // 
            labelProducto.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelProducto.Location = new Point(3, 10);
            labelProducto.Name = "labelProducto";
            labelProducto.Size = new Size(133, 15);
            labelProducto.TabIndex = 8;
            labelProducto.Text = "Detalle";
            // 
            // labelCantidad
            // 
            labelCantidad.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelCantidad.Location = new Point(142, 10);
            labelCantidad.Name = "labelCantidad";
            labelCantidad.Size = new Size(45, 15);
            labelCantidad.TabIndex = 9;
            labelCantidad.Text = "Cantidad";
            labelCantidad.TextAlign = ContentAlignment.TopRight;
            // 
            // CocinaProducto
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(labelCantidad);
            Controls.Add(labelProducto);
            Name = "CocinaProducto";
            Size = new Size(190, 35);
            ResumeLayout(false);
        }

        #endregion

        private Label labelProducto;
        private Label labelCantidad;
    }
}
