﻿using Google.Protobuf.WellKnownTypes;
using Logica;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Interfaces
{
    public partial class CocinaPedido : UserControl
    {
        public Pedido Pedido { get; set; }
        public CocinaPedido(Pedido p)
        {
            InitializeComponent();
            this.Pedido = p;
            setValores();
        }

        public void setValores()
        {
            labelId.Text = "" + Pedido.id;
            List<Producto> productos = Pedido.Productos;
            int x = 0;
            int y = 0;
            foreach (Producto producto in productos)
            {
                CocinaProducto cp = new CocinaProducto(producto);
                // cocinaPedido.setValores();
                this.panelProductos.Controls.Add((Control)cp);
                y += 35;
                cp.Location = new Point(x, y);
            }
        }

        private void botonEstado_Click(object sender, EventArgs e)
        {
            // Cambia el estado del pedido
        }
    }
}
