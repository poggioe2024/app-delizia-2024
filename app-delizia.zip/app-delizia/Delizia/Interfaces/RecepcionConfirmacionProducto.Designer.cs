﻿namespace Interfaces
{
    partial class RecepcionConfirmacionProducto
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            labelPrecio = new Label();
            labelProducto = new Label();
            labelCantidad = new Label();
            SuspendLayout();
            // 
            // labelPrecio
            // 
            labelPrecio.Location = new Point(240, 10);
            labelPrecio.Name = "labelPrecio";
            labelPrecio.Size = new Size(55, 15);
            labelPrecio.TabIndex = 7;
            labelPrecio.Text = "Precio";
            labelPrecio.TextAlign = ContentAlignment.TopCenter;
            // 
            // labelProducto
            // 
            labelProducto.Location = new Point(71, 10);
            labelProducto.Name = "labelProducto";
            labelProducto.Size = new Size(163, 15);
            labelProducto.TabIndex = 6;
            labelProducto.Text = "Detalle";
            labelProducto.TextAlign = ContentAlignment.TopCenter;
            // 
            // labelCantidad
            // 
            labelCantidad.Location = new Point(10, 10);
            labelCantidad.Name = "labelCantidad";
            labelCantidad.Size = new Size(55, 15);
            labelCantidad.TabIndex = 5;
            labelCantidad.Text = "Cantidad";
            labelCantidad.TextAlign = ContentAlignment.TopCenter;
            // 
            // RecepcionConfirmacionProducto
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(labelPrecio);
            Controls.Add(labelProducto);
            Controls.Add(labelCantidad);
            Name = "RecepcionConfirmacionProducto";
            Size = new Size(305, 35);
            ResumeLayout(false);
        }

        #endregion

        private Label labelPrecio;
        private Label labelProducto;
        private Label labelCantidad;
    }
}
