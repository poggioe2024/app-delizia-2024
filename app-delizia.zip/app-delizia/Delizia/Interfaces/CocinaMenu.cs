﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Interfaces
{
    public partial class CocinaMenu : UserControl
    {
        App parent;
        int documento;
        public CocinaMenu(App parent, int documento)
        {
            InitializeComponent();
            this.parent = parent;
            this.documento = documento;
        }

        private void botonPedido_Click(object sender, EventArgs e)
        {
            CocinaSeleccion m = new CocinaSeleccion(parent, documento);
            parent.Controls.Add(m);
            parent.Controls.Remove(this);
        }

        private void botonSalir_Click(object sender, EventArgs e)
        {
            parent.Dispose();
        }
    }
}
