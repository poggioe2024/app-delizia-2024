﻿using Logica;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Interfaces
{
    public partial class CocinaProducto : UserControl
    {
        public Producto Producto { get; set; }
        public CocinaProducto(Producto p)
        {
            InitializeComponent();
            this.Producto = p;
            setValores();
        }
        public void setValores()
        {
            labelCantidad.Text = "" + Producto.Cantidad;
            labelProducto.Text = "" + Producto.Nombre;
        }
    }
}
