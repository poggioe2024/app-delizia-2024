﻿namespace Interfaces
{
    partial class CocinaSeleccion
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panelPrincipal = new Panel();
            panelPedidos = new Panel();
            panelControl = new Panel();
            botonCancelar = new Button();
            panelPrincipal.SuspendLayout();
            panelControl.SuspendLayout();
            SuspendLayout();
            // 
            // panelPrincipal
            // 
            panelPrincipal.BackColor = Color.FromArgb(30, 30, 36);
            panelPrincipal.BorderStyle = BorderStyle.FixedSingle;
            panelPrincipal.Controls.Add(panelPedidos);
            panelPrincipal.Controls.Add(panelControl);
            panelPrincipal.Location = new Point(50, 50);
            panelPrincipal.Name = "panelPrincipal";
            panelPrincipal.Size = new Size(700, 500);
            panelPrincipal.TabIndex = 1;
            // 
            // panelPedidos
            // 
            panelPedidos.AutoScroll = true;
            panelPedidos.Location = new Point(10, 10);
            panelPedidos.Name = "panelPedidos";
            panelPedidos.Size = new Size(680, 420);
            panelPedidos.TabIndex = 1;
            // 
            // panelControl
            // 
            panelControl.Controls.Add(botonCancelar);
            panelControl.Location = new Point(10, 439);
            panelControl.Name = "panelControl";
            panelControl.Size = new Size(680, 50);
            panelControl.TabIndex = 0;
            // 
            // botonCancelar
            // 
            botonCancelar.BackColor = Color.FromArgb(218, 44, 56);
            botonCancelar.FlatStyle = FlatStyle.Popup;
            botonCancelar.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            botonCancelar.ForeColor = Color.FromArgb(247, 243, 227);
            botonCancelar.Location = new Point(7, 7);
            botonCancelar.Name = "botonCancelar";
            botonCancelar.Size = new Size(150, 35);
            botonCancelar.TabIndex = 1;
            botonCancelar.Text = "Atrás";
            botonCancelar.UseVisualStyleBackColor = false;
            botonCancelar.Click += botonCancelar_Click;
            // 
            // CocinaSeleccion
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.fondo;
            Controls.Add(panelPrincipal);
            Name = "CocinaSeleccion";
            Size = new Size(800, 600);
            panelPrincipal.ResumeLayout(false);
            panelControl.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel panelPrincipal;
        private Panel panelPedidos;
        private Panel panelControl;
        private Button botonCancelar;
    }
}
