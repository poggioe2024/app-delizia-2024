﻿namespace Interfaces
{
    partial class RecepcionMenu
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            panelMenu = new Panel();
            botonSalir = new Button();
            botonPedido = new Button();
            panelMenu.SuspendLayout();
            SuspendLayout();
            // 
            // panelMenu
            // 
            panelMenu.BackColor = Color.FromArgb(30, 30, 36);
            panelMenu.BorderStyle = BorderStyle.FixedSingle;
            panelMenu.Controls.Add(botonSalir);
            panelMenu.Controls.Add(botonPedido);
            panelMenu.Location = new Point(50, 50);
            panelMenu.Name = "panelMenu";
            panelMenu.Size = new Size(300, 500);
            panelMenu.TabIndex = 0;
            // 
            // botonSalir
            // 
            botonSalir.BackColor = Color.FromArgb(218, 44, 56);
            botonSalir.FlatStyle = FlatStyle.Popup;
            botonSalir.Font = new Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point, 0);
            botonSalir.ForeColor = Color.FromArgb(247, 243, 227);
            botonSalir.Location = new Point(50, 210);
            botonSalir.Name = "botonSalir";
            botonSalir.Size = new Size(200, 45);
            botonSalir.TabIndex = 1;
            botonSalir.Text = "Salir";
            botonSalir.UseVisualStyleBackColor = false;
            botonSalir.Click += botonSalir_Click;
            // 
            // botonPedido
            // 
            botonPedido.BackColor = Color.FromArgb(255, 202, 41);
            botonPedido.FlatStyle = FlatStyle.Popup;
            botonPedido.Font = new Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point, 0);
            botonPedido.ForeColor = Color.FromArgb(30, 30, 36);
            botonPedido.Location = new Point(50, 150);
            botonPedido.Name = "botonPedido";
            botonPedido.Size = new Size(200, 45);
            botonPedido.TabIndex = 0;
            botonPedido.Text = "Pedido";
            botonPedido.UseVisualStyleBackColor = false;
            botonPedido.Click += botonPedido_Click;
            // 
            // RecepcionMenu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.fondo;
            Controls.Add(panelMenu);
            Name = "RecepcionMenu";
            Size = new Size(800, 600);
            panelMenu.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel panelMenu;
        private Button botonSalir;
        private Button botonPedido;
    }
}
