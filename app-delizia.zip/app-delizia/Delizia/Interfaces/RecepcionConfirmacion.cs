﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Logica;
using Datos;
using Mysqlx.Cursor;
using static System.Runtime.InteropServices.JavaScript.JSType;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace Interfaces
{
    public partial class RecepcionConfirmacion : UserControl
    {
        App parent;
        RecepcionSeleccion recepcionSeleccion;
        List<Producto> productos;
        int documento;
        public RecepcionConfirmacion(App parent, RecepcionSeleccion recepcionSeleccion, List<Producto> productos, int documento)
        {
            InitializeComponent();
            this.parent = parent;
            this.recepcionSeleccion = recepcionSeleccion;
            this.productos = productos;
            this.documento = documento;
            mostrarProductos(productos);
        }

        public void mostrarProductos(List<Producto> listaProductos)
        {
            int x = 0;
            int y = 40;
            double precioTotal = 0;
            foreach (Producto listaProducto in listaProductos)
            {
                precioTotal += (listaProducto.Precio * listaProducto.Cantidad);
                RecepcionConfirmacionProducto recepcionProducto = new RecepcionConfirmacionProducto(listaProducto);
                recepcionProducto.setValores();
                this.panelPedidos.Controls.Add((Control)recepcionProducto);
                recepcionProducto.Location = new Point(x, y);
                y += 35;
            }
            labelPrecioTotal.Text = "" + precioTotal;
        }

        private void botonRetroceder_Click(object sender, EventArgs e)
        {
            this.parent.Controls.Remove((Control)this);
            this.parent.Controls.Add((Control)recepcionSeleccion);
        }

        private void botonFinalizar_Click(object sender, EventArgs e)
        {
            LRecepcion lrecepcion = new LRecepcion();
            nuevoPedido();
            RecepcionMenu recepcionMenu = new RecepcionMenu(this.parent, documento);
            this.parent.Controls.Remove((Control)this);
            this.parent.Controls.Add((Control)recepcionMenu);
        }

        private void nuevoPedido()
        {
            DateOnly fecha = DateOnly.FromDateTime(DateTime.Now); TimeOnly hora = TimeOnly.FromDateTime(DateTime.Now);
            double precio = double.Parse(labelPrecioTotal.Text); int estado = 1; int cajero = documento;
            string nombre = txtNombre.Text; string telefono = txtTelefono.Text; string calle1 = txtCalle.Text; string calle2 = txtCalle2.Text; int numeroPuerta = int.Parse(txtPuerta.Text); string detalle = txtDetalle.Text;
            List<int> productosId = new List<int>();
            List<int> productosCantidad = new List<int>();
            foreach(Producto p in productos)
            {
                productosId.Add(p.Id);
                productosCantidad.Add(p.Cantidad);
            }
            DRecepcion d = new DRecepcion();
            d.crearPedido(fecha, hora, precio, estado, cajero, nombre, telefono, calle1, calle2, numeroPuerta, detalle, productosId, productosCantidad);
        }
    }
}
