﻿
namespace Interfaces
{
    partial class RecepcionConfirmacion
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            panelControl = new Panel();
            botonRetroceder = new Button();
            botonFinalizar = new Button();
            panelPrincipal = new Panel();
            panelPedido = new Panel();
            panelDetalles = new Panel();
            labelPrecioTotal = new Label();
            labelP = new Label();
            labelSubtitulo = new Label();
            panelPedidos = new Panel();
            labelPrecio = new Label();
            labelProducto = new Label();
            labelCantidad = new Label();
            panelCliente = new Panel();
            txtCalle2 = new TextBox();
            labelCalle2 = new Label();
            txtDetalle = new TextBox();
            labelDetalle = new Label();
            txtPuerta = new TextBox();
            labelPuerta = new Label();
            txtCalle = new TextBox();
            labelCalle = new Label();
            txtTelefono = new TextBox();
            labelTelefono = new Label();
            txtNombre = new TextBox();
            labelNombre = new Label();
            panelControl.SuspendLayout();
            panelPrincipal.SuspendLayout();
            panelPedido.SuspendLayout();
            panelDetalles.SuspendLayout();
            panelPedidos.SuspendLayout();
            panelCliente.SuspendLayout();
            SuspendLayout();
            // 
            // panelControl
            // 
            panelControl.Controls.Add(botonRetroceder);
            panelControl.Controls.Add(botonFinalizar);
            panelControl.Location = new Point(10, 439);
            panelControl.Name = "panelControl";
            panelControl.Size = new Size(680, 50);
            panelControl.TabIndex = 0;
            // 
            // botonRetroceder
            // 
            botonRetroceder.Location = new Point(3, 24);
            botonRetroceder.Name = "botonRetroceder";
            botonRetroceder.Size = new Size(75, 23);
            botonRetroceder.TabIndex = 1;
            botonRetroceder.Text = "Retroceder";
            botonRetroceder.UseVisualStyleBackColor = true;
            botonRetroceder.Click += botonRetroceder_Click;
            // 
            // botonFinalizar
            // 
            botonFinalizar.Location = new Point(602, 24);
            botonFinalizar.Name = "botonFinalizar";
            botonFinalizar.Size = new Size(75, 23);
            botonFinalizar.TabIndex = 0;
            botonFinalizar.Text = "Finalizar";
            botonFinalizar.UseVisualStyleBackColor = true;
            botonFinalizar.Click += botonFinalizar_Click;
            // 
            // panelPrincipal
            // 
            panelPrincipal.BorderStyle = BorderStyle.FixedSingle;
            panelPrincipal.Controls.Add(panelPedido);
            panelPrincipal.Controls.Add(panelControl);
            panelPrincipal.Location = new Point(50, 50);
            panelPrincipal.Name = "panelPrincipal";
            panelPrincipal.Size = new Size(700, 500);
            panelPrincipal.TabIndex = 1;
            // 
            // panelPedido
            // 
            panelPedido.AutoScroll = true;
            panelPedido.Controls.Add(panelDetalles);
            panelPedido.Controls.Add(panelCliente);
            panelPedido.Location = new Point(10, 10);
            panelPedido.Name = "panelPedido";
            panelPedido.Size = new Size(680, 420);
            panelPedido.TabIndex = 1;
            // 
            // panelDetalles
            // 
            panelDetalles.BorderStyle = BorderStyle.FixedSingle;
            panelDetalles.Controls.Add(labelPrecioTotal);
            panelDetalles.Controls.Add(labelP);
            panelDetalles.Controls.Add(labelSubtitulo);
            panelDetalles.Controls.Add(panelPedidos);
            panelDetalles.Location = new Point(345, 10);
            panelDetalles.Name = "panelDetalles";
            panelDetalles.Size = new Size(325, 400);
            panelDetalles.TabIndex = 1;
            // 
            // labelPrecioTotal
            // 
            labelPrecioTotal.AutoSize = true;
            labelPrecioTotal.Location = new Point(86, 339);
            labelPrecioTotal.Name = "labelPrecioTotal";
            labelPrecioTotal.Size = new Size(13, 15);
            labelPrecioTotal.TabIndex = 6;
            labelPrecioTotal.Text = "$";
            labelPrecioTotal.TextAlign = ContentAlignment.TopCenter;
            // 
            // labelP
            // 
            labelP.AutoSize = true;
            labelP.Location = new Point(10, 339);
            labelP.Name = "labelP";
            labelP.Size = new Size(70, 15);
            labelP.TabIndex = 5;
            labelP.Text = "Precio total:";
            labelP.TextAlign = ContentAlignment.TopCenter;
            // 
            // labelSubtitulo
            // 
            labelSubtitulo.AutoSize = true;
            labelSubtitulo.Location = new Point(10, 10);
            labelSubtitulo.Name = "labelSubtitulo";
            labelSubtitulo.Size = new Size(107, 15);
            labelSubtitulo.TabIndex = 1;
            labelSubtitulo.Text = "Detalles del Pedido";
            // 
            // panelPedidos
            // 
            panelPedidos.AutoScroll = true;
            panelPedidos.Controls.Add(labelPrecio);
            panelPedidos.Controls.Add(labelProducto);
            panelPedidos.Controls.Add(labelCantidad);
            panelPedidos.Location = new Point(10, 36);
            panelPedidos.Name = "panelPedidos";
            panelPedidos.Size = new Size(305, 300);
            panelPedidos.TabIndex = 0;
            // 
            // labelPrecio
            // 
            labelPrecio.Location = new Point(240, 10);
            labelPrecio.Name = "labelPrecio";
            labelPrecio.Size = new Size(55, 15);
            labelPrecio.TabIndex = 4;
            labelPrecio.Text = "Precio";
            labelPrecio.TextAlign = ContentAlignment.TopCenter;
            // 
            // labelProducto
            // 
            labelProducto.Location = new Point(71, 10);
            labelProducto.Name = "labelProducto";
            labelProducto.Size = new Size(163, 15);
            labelProducto.TabIndex = 3;
            labelProducto.Text = "Detalle";
            labelProducto.TextAlign = ContentAlignment.TopCenter;
            // 
            // labelCantidad
            // 
            labelCantidad.Location = new Point(10, 10);
            labelCantidad.Name = "labelCantidad";
            labelCantidad.Size = new Size(55, 15);
            labelCantidad.TabIndex = 2;
            labelCantidad.Text = "Cantidad";
            labelCantidad.TextAlign = ContentAlignment.TopCenter;
            // 
            // panelCliente
            // 
            panelCliente.BorderStyle = BorderStyle.FixedSingle;
            panelCliente.Controls.Add(txtCalle2);
            panelCliente.Controls.Add(labelCalle2);
            panelCliente.Controls.Add(txtDetalle);
            panelCliente.Controls.Add(labelDetalle);
            panelCliente.Controls.Add(txtPuerta);
            panelCliente.Controls.Add(labelPuerta);
            panelCliente.Controls.Add(txtCalle);
            panelCliente.Controls.Add(labelCalle);
            panelCliente.Controls.Add(txtTelefono);
            panelCliente.Controls.Add(labelTelefono);
            panelCliente.Controls.Add(txtNombre);
            panelCliente.Controls.Add(labelNombre);
            panelCliente.Location = new Point(10, 10);
            panelCliente.Name = "panelCliente";
            panelCliente.Size = new Size(325, 400);
            panelCliente.TabIndex = 0;
            // 
            // txtCalle2
            // 
            txtCalle2.Location = new Point(3, 192);
            txtCalle2.Name = "txtCalle2";
            txtCalle2.Size = new Size(100, 23);
            txtCalle2.TabIndex = 11;
            // 
            // labelCalle2
            // 
            labelCalle2.Location = new Point(3, 166);
            labelCalle2.Name = "labelCalle2";
            labelCalle2.Size = new Size(100, 23);
            labelCalle2.TabIndex = 10;
            labelCalle2.Text = "Calle 2";
            // 
            // txtDetalle
            // 
            txtDetalle.Location = new Point(3, 296);
            txtDetalle.Name = "txtDetalle";
            txtDetalle.Size = new Size(100, 23);
            txtDetalle.TabIndex = 9;
            // 
            // labelDetalle
            // 
            labelDetalle.Location = new Point(3, 270);
            labelDetalle.Name = "labelDetalle";
            labelDetalle.Size = new Size(100, 23);
            labelDetalle.TabIndex = 8;
            labelDetalle.Text = "Detalle";
            // 
            // txtPuerta
            // 
            txtPuerta.Location = new Point(3, 244);
            txtPuerta.Name = "txtPuerta";
            txtPuerta.Size = new Size(100, 23);
            txtPuerta.TabIndex = 7;
            // 
            // labelPuerta
            // 
            labelPuerta.Location = new Point(3, 218);
            labelPuerta.Name = "labelPuerta";
            labelPuerta.Size = new Size(100, 23);
            labelPuerta.TabIndex = 6;
            labelPuerta.Text = "Núm. Puerta";
            // 
            // txtCalle
            // 
            txtCalle.Location = new Point(3, 140);
            txtCalle.Name = "txtCalle";
            txtCalle.Size = new Size(100, 23);
            txtCalle.TabIndex = 5;
            // 
            // labelCalle
            // 
            labelCalle.Location = new Point(3, 114);
            labelCalle.Name = "labelCalle";
            labelCalle.Size = new Size(100, 23);
            labelCalle.TabIndex = 4;
            labelCalle.Text = "Calle";
            // 
            // txtTelefono
            // 
            txtTelefono.Location = new Point(3, 88);
            txtTelefono.Name = "txtTelefono";
            txtTelefono.Size = new Size(100, 23);
            txtTelefono.TabIndex = 3;
            // 
            // labelTelefono
            // 
            labelTelefono.Location = new Point(3, 62);
            labelTelefono.Name = "labelTelefono";
            labelTelefono.Size = new Size(100, 23);
            labelTelefono.TabIndex = 2;
            labelTelefono.Text = "Teléfono";
            // 
            // txtNombre
            // 
            txtNombre.Location = new Point(3, 36);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(100, 23);
            txtNombre.TabIndex = 1;
            // 
            // labelNombre
            // 
            labelNombre.Location = new Point(10, 10);
            labelNombre.Name = "labelNombre";
            labelNombre.Size = new Size(100, 23);
            labelNombre.TabIndex = 0;
            labelNombre.Text = "Nombre";
            // 
            // RecepcionConfirmacion
            // 
            BackgroundImage = Properties.Resources.fondo;
            Controls.Add(panelPrincipal);
            Name = "RecepcionConfirmacion";
            Size = new Size(800, 600);
            panelControl.ResumeLayout(false);
            panelPrincipal.ResumeLayout(false);
            panelPedido.ResumeLayout(false);
            panelDetalles.ResumeLayout(false);
            panelDetalles.PerformLayout();
            panelPedidos.ResumeLayout(false);
            panelCliente.ResumeLayout(false);
            panelCliente.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panelControl;
        private Button botonRetroceder;
        private Button botonFinalizar;
        private Panel panelPrincipal;
        private Panel panelPedido;
        private Panel panelDetalles;
        private Panel panelCliente;
        private TextBox txtDetalle;
        private Label labelDetalle;
        private TextBox txtPuerta;
        private Label labelPuerta;
        private TextBox txtCalle;
        private Label labelCalle;
        private TextBox txtTelefono;
        private Label labelTelefono;
        private TextBox txtNombre;
        private Label labelNombre;
        private Panel panelPedidos;
        private Label labelSubtitulo;
        private Label labelCantidad;
        private Label labelPrecio;
        private Label labelProducto;
        private Label labelPrecioTotal;
        private Label labelP;
        private TextBox txtCalle2;
        private Label labelCalle2;
    }
}
