﻿namespace Interfaces
{
    partial class RecepcionProducto
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            imagenProducto = new PictureBox();
            botonQuitar = new Button();
            botonAgregar = new Button();
            labelCantidad = new Label();
            labelNombre = new Label();
            labelPrecio = new Label();
            labelId = new Label();
            ((System.ComponentModel.ISupportInitialize)imagenProducto).BeginInit();
            SuspendLayout();
            // 
            // imagenProducto
            // 
            imagenProducto.Location = new Point(40, 20);
            imagenProducto.Name = "imagenProducto";
            imagenProducto.Size = new Size(120, 120);
            imagenProducto.SizeMode = PictureBoxSizeMode.StretchImage;
            imagenProducto.TabIndex = 0;
            imagenProducto.TabStop = false;
            // 
            // botonQuitar
            // 
            botonQuitar.Location = new Point(3, 224);
            botonQuitar.Name = "botonQuitar";
            botonQuitar.Size = new Size(23, 23);
            botonQuitar.TabIndex = 1;
            botonQuitar.Text = "-";
            botonQuitar.UseVisualStyleBackColor = true;
            botonQuitar.Click += botonQuitar_Click;
            // 
            // botonAgregar
            // 
            botonAgregar.Location = new Point(174, 224);
            botonAgregar.Name = "botonAgregar";
            botonAgregar.Size = new Size(23, 23);
            botonAgregar.TabIndex = 2;
            botonAgregar.Text = "+";
            botonAgregar.UseVisualStyleBackColor = true;
            botonAgregar.Click += botonAgregar_Click;
            // 
            // labelCantidad
            // 
            labelCantidad.Location = new Point(80, 228);
            labelCantidad.Name = "labelCantidad";
            labelCantidad.Size = new Size(40, 13);
            labelCantidad.TabIndex = 3;
            labelCantidad.Text = "0";
            labelCantidad.TextAlign = ContentAlignment.TopCenter;
            // 
            // labelNombre
            // 
            labelNombre.Location = new Point(10, 149);
            labelNombre.Name = "labelNombre";
            labelNombre.Size = new Size(180, 13);
            labelNombre.TabIndex = 4;
            labelNombre.Text = "Nombre del producto";
            labelNombre.TextAlign = ContentAlignment.TopCenter;
            // 
            // labelPrecio
            // 
            labelPrecio.Location = new Point(10, 177);
            labelPrecio.Name = "labelPrecio";
            labelPrecio.Size = new Size(180, 13);
            labelPrecio.TabIndex = 5;
            labelPrecio.Text = "$000";
            labelPrecio.TextAlign = ContentAlignment.TopCenter;
            // 
            // labelId
            // 
            labelId.Location = new Point(10, 3);
            labelId.Name = "labelId";
            labelId.Size = new Size(180, 13);
            labelId.TabIndex = 6;
            labelId.Text = "0";
            labelId.TextAlign = ContentAlignment.TopCenter;
            // 
            // RecepcionProducto
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BorderStyle = BorderStyle.FixedSingle;
            Controls.Add(labelId);
            Controls.Add(labelPrecio);
            Controls.Add(labelNombre);
            Controls.Add(labelCantidad);
            Controls.Add(botonAgregar);
            Controls.Add(botonQuitar);
            Controls.Add(imagenProducto);
            Name = "RecepcionProducto";
            Size = new Size(200, 250);
            ((System.ComponentModel.ISupportInitialize)imagenProducto).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private PictureBox imagenProducto;
        private Button botonQuitar;
        private Button botonAgregar;
        private Label labelCantidad;
        private Label labelNombre;
        private Label labelPrecio;
        private Label labelId;
    }
}
