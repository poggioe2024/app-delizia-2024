﻿using Datos;
using Logica;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Interfaces
{
    public partial class RecepcionSeleccion : UserControl
    {
        App parent;
        List<Producto> productos;
        List<RecepcionProducto> productosGrafico = new List<RecepcionProducto>();
        int documento;
        public RecepcionSeleccion(App parent, int documento)
        {
            InitializeComponent();
            this.parent = parent;
            this.productos = obtenerProductos();
            this.documento = documento;
            mostrarProductos(productos);
        }

        private void botonCancelar_Click(object sender, EventArgs e)
        {
            RecepcionMenu recepcionMenu = new RecepcionMenu(this.parent, documento);
            this.parent.Controls.Remove((Control)this);
            this.parent.Controls.Add((Control)recepcionMenu);
        }

        private void botonSiguiente_Click(object sender, EventArgs e)
        {
            //List<Producto> productosSeleccionados = this.productos.Clone();
            List<Producto> productos2 = obtenerCantidades(productosGrafico);
            productos2.RemoveAll(p => p.Cantidad == 0);
            RecepcionConfirmacion recepcionConfirmacion = new RecepcionConfirmacion(this.parent, this, productos2, documento);
            this.parent.Controls.Remove((Control)this);
            this.parent.Controls.Add((Control)recepcionConfirmacion);
        }

        private List<Producto> obtenerProductos()
        {
            DRecepcion drecepcion = new DRecepcion();
            LRecepcion lrecepcion = new LRecepcion();
            this.eliminarProductos();
            return lrecepcion.obtenerProductos();
        }

        private List<Producto> obtenerCantidades(List<RecepcionProducto> productosGraficos)
        {
            List<Producto> productos = new List<Producto>();
            foreach (RecepcionProducto p in productosGraficos)
            {
                productos.Add(p.getProducto());
            }
            return productos;
        }

        public void mostrarProductos(List<Producto> listaProductos)
        {
            int num = 1;
            int x = 10;
            int y = 20;
            foreach (Producto listaProducto in listaProductos)
            {
                RecepcionProducto recepcionProducto = new RecepcionProducto(listaProducto);
                recepcionProducto.setValores();
                this.panelProductos.Controls.Add((Control)recepcionProducto);
                this.productosGrafico.Add(recepcionProducto);
                recepcionProducto.Location = new Point(x, y);
                if (num % 3 == 0)
                {
                    x = 10;
                    y += 270;
                }
                else
                    x += 220;
                ++num;
            }
        }
        private void eliminarProductos()
        {
        }
    }
}
