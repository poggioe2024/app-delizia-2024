﻿namespace Interfaces
{
    partial class RecepcionSeleccion
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            panelPrincipal = new Panel();
            panelProductos = new Panel();
            panelControl = new Panel();
            botonCancelar = new Button();
            botonSiguiente = new Button();
            panelPrincipal.SuspendLayout();
            panelControl.SuspendLayout();
            SuspendLayout();
            // 
            // panelPrincipal
            // 
            panelPrincipal.BackColor = Color.FromArgb(30, 30, 36);
            panelPrincipal.BorderStyle = BorderStyle.FixedSingle;
            panelPrincipal.Controls.Add(panelProductos);
            panelPrincipal.Controls.Add(panelControl);
            panelPrincipal.Location = new Point(50, 50);
            panelPrincipal.Name = "panelPrincipal";
            panelPrincipal.Size = new Size(700, 500);
            panelPrincipal.TabIndex = 0;
            // 
            // panelProductos
            // 
            panelProductos.AutoScroll = true;
            panelProductos.Location = new Point(10, 10);
            panelProductos.Name = "panelProductos";
            panelProductos.Size = new Size(680, 420);
            panelProductos.TabIndex = 1;
            // 
            // panelControl
            // 
            panelControl.Controls.Add(botonCancelar);
            panelControl.Controls.Add(botonSiguiente);
            panelControl.Location = new Point(10, 439);
            panelControl.Name = "panelControl";
            panelControl.Size = new Size(680, 50);
            panelControl.TabIndex = 0;
            // 
            // botonCancelar
            // 
            botonCancelar.BackColor = Color.FromArgb(218, 44, 56);
            botonCancelar.FlatStyle = FlatStyle.Popup;
            botonCancelar.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            botonCancelar.ForeColor = Color.FromArgb(247, 243, 227);
            botonCancelar.Location = new Point(7, 7);
            botonCancelar.Name = "botonCancelar";
            botonCancelar.Size = new Size(150, 35);
            botonCancelar.TabIndex = 1;
            botonCancelar.Text = "Cancelar";
            botonCancelar.UseVisualStyleBackColor = false;
            botonCancelar.Click += botonCancelar_Click;
            // 
            // botonSiguiente
            // 
            botonSiguiente.BackColor = Color.FromArgb(83, 165, 72);
            botonSiguiente.FlatStyle = FlatStyle.Popup;
            botonSiguiente.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            botonSiguiente.ForeColor = Color.FromArgb(247, 243, 227);
            botonSiguiente.Location = new Point(523, 7);
            botonSiguiente.Name = "botonSiguiente";
            botonSiguiente.Size = new Size(150, 35);
            botonSiguiente.TabIndex = 0;
            botonSiguiente.Text = "Siguiente";
            botonSiguiente.UseVisualStyleBackColor = false;
            botonSiguiente.Click += botonSiguiente_Click;
            // 
            // RecepcionSeleccion
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.fondo;
            Controls.Add(panelPrincipal);
            Name = "RecepcionSeleccion";
            Size = new Size(800, 600);
            panelPrincipal.ResumeLayout(false);
            panelControl.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel panelPrincipal;
        private Panel panelControl;
        private Button botonCancelar;
        private Button botonSiguiente;
        private Panel panelProductos;
    }
}
