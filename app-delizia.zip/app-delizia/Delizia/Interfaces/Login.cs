﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Datos;

namespace Interfaces
{
    public partial class Login : UserControl
    {
        App parent;
        public Login(App parent)
        {
            InitializeComponent();
            this.parent = parent;
        }
        private void botonIngresar_Click(object sender, EventArgs e)
        {
            string documento = txtDocumento.Text;
            string contrasena = txtContrasena.Text;
            limpiarCampos();
            if (documento != string.Empty && contrasena != string.Empty)
            {
                DLogin dlogin = new DLogin();
                bool check = dlogin.checkCredenciales(documento, contrasena);
                if (check)
                {
                    int rol = dlogin.getRol(documento);
                    cambiarMenu(rol, int.Parse(documento));
                }
            }
            else
            {
                MessageBox.Show("Hay campos sin completar. Por favor completelos e intente de nuevo.", "Error");
            }
        }
        private void botonBorrar_Click(object sender, EventArgs e)
        {
            limpiarCampos();
        }

        private void cambiarMenu(int rol, int documento)
        {
            if (rol == 1) { }
            else if (rol == 2)
            {
                RecepcionMenu recepcionMenu = new RecepcionMenu(parent, documento);
                parent.Controls.Remove(this);
                parent.Controls.Add(recepcionMenu);
            }
            else if (rol == 3)
            {
                CocinaMenu m = new CocinaMenu(parent, documento);
                parent.Controls.Add(m);
                parent.Controls.Remove(this);
            }
            else if (rol == 4) { }
            else { }
        }

        private void limpiarCampos()
        {
            txtDocumento.Text = string.Empty;
            txtContrasena.Text = string.Empty;
        }

        private void txtDocumento_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
