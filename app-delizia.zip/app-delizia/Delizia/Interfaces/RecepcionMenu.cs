﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Interfaces
{
    public partial class RecepcionMenu : UserControl
    {
        App parent;
        int documento;
        public RecepcionMenu(App parent, int documento)
        {
            InitializeComponent();
            this.parent = parent;
            this.documento = documento;
        }

        private void botonSalir_Click(object sender, EventArgs e)
        {
            parent.Dispose();
        }

        private void botonPedido_Click(object sender, EventArgs e)
        {
            RecepcionSeleccion recepcionSeleccion = new RecepcionSeleccion(parent, documento);
            parent.Controls.Remove(this);
            parent.Controls.Add(recepcionSeleccion);
        }
    }
}
