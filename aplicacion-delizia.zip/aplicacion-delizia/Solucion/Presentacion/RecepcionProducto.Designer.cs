﻿namespace Presentacion
{
    partial class RecepcionProducto
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            imagen = new PictureBox();
            lblId = new Label();
            lblNombre = new Label();
            lblPrecio = new Label();
            lblCantidad = new Label();
            btnRestar = new Button();
            btnSumar = new Button();
            ((System.ComponentModel.ISupportInitialize)imagen).BeginInit();
            SuspendLayout();
            // 
            // imagen
            // 
            imagen.Location = new Point(10, 10);
            imagen.Name = "imagen";
            imagen.Size = new Size(160, 160);
            imagen.TabIndex = 0;
            imagen.TabStop = false;
            // 
            // lblId
            // 
            lblId.AutoSize = true;
            lblId.Location = new Point(176, 10);
            lblId.Name = "lblId";
            lblId.Size = new Size(17, 15);
            lblId.TabIndex = 1;
            lblId.Text = "Id";
            // 
            // lblNombre
            // 
            lblNombre.AutoSize = true;
            lblNombre.Location = new Point(176, 35);
            lblNombre.Name = "lblNombre";
            lblNombre.Size = new Size(122, 15);
            lblNombre.TabIndex = 2;
            lblNombre.Text = "Nombre del Producto";
            // 
            // lblPrecio
            // 
            lblPrecio.AutoSize = true;
            lblPrecio.Location = new Point(176, 60);
            lblPrecio.Name = "lblPrecio";
            lblPrecio.Size = new Size(40, 15);
            lblPrecio.TabIndex = 3;
            lblPrecio.Text = "Precio";
            // 
            // lblCantidad
            // 
            lblCantidad.Location = new Point(205, 151);
            lblCantidad.Name = "lblCantidad";
            lblCantidad.Size = new Size(38, 15);
            lblCantidad.TabIndex = 4;
            lblCantidad.Text = "0";
            lblCantidad.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // btnRestar
            // 
            btnRestar.Location = new Point(176, 147);
            btnRestar.Name = "btnRestar";
            btnRestar.Size = new Size(23, 23);
            btnRestar.TabIndex = 5;
            btnRestar.Text = "-";
            btnRestar.UseVisualStyleBackColor = true;
            btnRestar.Click += btnRestar_Click;
            // 
            // btnSumar
            // 
            btnSumar.Location = new Point(249, 147);
            btnSumar.Name = "btnSumar";
            btnSumar.Size = new Size(23, 23);
            btnSumar.TabIndex = 6;
            btnSumar.Text = "+";
            btnSumar.UseVisualStyleBackColor = true;
            btnSumar.Click += btnSumar_Click;
            // 
            // RecepcionProducto
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BorderStyle = BorderStyle.FixedSingle;
            Controls.Add(btnSumar);
            Controls.Add(btnRestar);
            Controls.Add(lblCantidad);
            Controls.Add(lblPrecio);
            Controls.Add(lblNombre);
            Controls.Add(lblId);
            Controls.Add(imagen);
            Name = "RecepcionProducto";
            Size = new Size(360, 180);
            ((System.ComponentModel.ISupportInitialize)imagen).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox imagen;
        private Label lblId;
        private Label lblNombre;
        private Label lblPrecio;
        private Label lblCantidad;
        private Button btnRestar;
        private Button btnSumar;
    }
}
