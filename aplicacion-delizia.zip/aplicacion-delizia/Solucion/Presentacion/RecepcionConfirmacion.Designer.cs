﻿namespace Presentacion
{
    partial class RecepcionConfirmacion
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panPrincipal = new Panel();
            btnConfirmar = new Button();
            btnAtras = new Button();
            panInfo = new Panel();
            panel2 = new Panel();
            panProductos = new Panel();
            lblPrecioTotal = new Label();
            label7 = new Label();
            panel1 = new Panel();
            txtDetalle = new TextBox();
            label6 = new Label();
            txtPuerta = new TextBox();
            label5 = new Label();
            txtCalle2 = new TextBox();
            label4 = new Label();
            txtCalle = new TextBox();
            label3 = new Label();
            txtTelefono = new TextBox();
            label2 = new Label();
            txtNombre = new TextBox();
            label1 = new Label();
            panPrincipal.SuspendLayout();
            panInfo.SuspendLayout();
            panel2.SuspendLayout();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // panPrincipal
            // 
            panPrincipal.Controls.Add(btnConfirmar);
            panPrincipal.Controls.Add(btnAtras);
            panPrincipal.Controls.Add(panInfo);
            panPrincipal.Location = new Point(10, 10);
            panPrincipal.Name = "panPrincipal";
            panPrincipal.Size = new Size(780, 380);
            panPrincipal.TabIndex = 1;
            // 
            // btnConfirmar
            // 
            btnConfirmar.Location = new Point(700, 350);
            btnConfirmar.Name = "btnConfirmar";
            btnConfirmar.Size = new Size(75, 23);
            btnConfirmar.TabIndex = 2;
            btnConfirmar.Text = "Confirmar";
            btnConfirmar.UseVisualStyleBackColor = true;
            btnConfirmar.Click += btnConfirmar_Click;
            // 
            // btnAtras
            // 
            btnAtras.Location = new Point(5, 350);
            btnAtras.Name = "btnAtras";
            btnAtras.Size = new Size(75, 23);
            btnAtras.TabIndex = 1;
            btnAtras.Text = "Atrás";
            btnAtras.UseVisualStyleBackColor = true;
            btnAtras.Click += btnAtras_Click_1;
            // 
            // panInfo
            // 
            panInfo.Controls.Add(panel2);
            panInfo.Controls.Add(panel1);
            panInfo.Location = new Point(5, 5);
            panInfo.Name = "panInfo";
            panInfo.Size = new Size(770, 330);
            panInfo.TabIndex = 0;
            // 
            // panel2
            // 
            panel2.Controls.Add(panProductos);
            panel2.Controls.Add(lblPrecioTotal);
            panel2.Controls.Add(label7);
            panel2.Location = new Point(395, 10);
            panel2.Name = "panel2";
            panel2.Size = new Size(365, 310);
            panel2.TabIndex = 1;
            // 
            // panProductos
            // 
            panProductos.Location = new Point(10, 30);
            panProductos.Name = "panProductos";
            panProductos.Size = new Size(345, 240);
            panProductos.TabIndex = 2;
            // 
            // lblPrecioTotal
            // 
            lblPrecioTotal.AutoSize = true;
            lblPrecioTotal.Location = new Point(10, 284);
            lblPrecioTotal.Name = "lblPrecioTotal";
            lblPrecioTotal.Size = new Size(44, 15);
            lblPrecioTotal.TabIndex = 1;
            lblPrecioTotal.Text = "Total: $";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(10, 10);
            label7.Name = "label7";
            label7.Size = new Size(107, 15);
            label7.TabIndex = 0;
            label7.Text = "Detalles del pedido";
            // 
            // panel1
            // 
            panel1.Controls.Add(txtDetalle);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(txtPuerta);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(txtCalle2);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(txtCalle);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(txtTelefono);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(txtNombre);
            panel1.Controls.Add(label1);
            panel1.Location = new Point(10, 10);
            panel1.Name = "panel1";
            panel1.Size = new Size(365, 310);
            panel1.TabIndex = 0;
            // 
            // txtDetalle
            // 
            txtDetalle.Location = new Point(10, 248);
            txtDetalle.Name = "txtDetalle";
            txtDetalle.Size = new Size(100, 23);
            txtDetalle.TabIndex = 11;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(10, 230);
            label6.Name = "label6";
            label6.Size = new Size(43, 15);
            label6.TabIndex = 10;
            label6.Text = "Detalle";
            // 
            // txtPuerta
            // 
            txtPuerta.Location = new Point(10, 204);
            txtPuerta.Name = "txtPuerta";
            txtPuerta.Size = new Size(100, 23);
            txtPuerta.TabIndex = 9;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(10, 186);
            label5.Name = "label5";
            label5.Size = new Size(41, 15);
            label5.TabIndex = 8;
            label5.Text = "Puerta";
            // 
            // txtCalle2
            // 
            txtCalle2.Location = new Point(10, 160);
            txtCalle2.Name = "txtCalle2";
            txtCalle2.Size = new Size(100, 23);
            txtCalle2.TabIndex = 7;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(10, 142);
            label4.Name = "label4";
            label4.Size = new Size(48, 15);
            label4.TabIndex = 6;
            label4.Text = "Esquina";
            // 
            // txtCalle
            // 
            txtCalle.Location = new Point(10, 116);
            txtCalle.Name = "txtCalle";
            txtCalle.Size = new Size(100, 23);
            txtCalle.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(10, 98);
            label3.Name = "label3";
            label3.Size = new Size(33, 15);
            label3.TabIndex = 4;
            label3.Text = "Calle";
            // 
            // txtTelefono
            // 
            txtTelefono.Location = new Point(10, 72);
            txtTelefono.Name = "txtTelefono";
            txtTelefono.Size = new Size(100, 23);
            txtTelefono.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(10, 54);
            label2.Name = "label2";
            label2.Size = new Size(52, 15);
            label2.TabIndex = 2;
            label2.Text = "Teléfono";
            // 
            // txtNombre
            // 
            txtNombre.Location = new Point(10, 28);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(100, 23);
            txtNombre.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(10, 10);
            label1.Name = "label1";
            label1.Size = new Size(51, 15);
            label1.TabIndex = 0;
            label1.Text = "Nombre";
            // 
            // RecepcionConfirmacion
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(panPrincipal);
            Name = "RecepcionConfirmacion";
            Size = new Size(800, 400);
            panPrincipal.ResumeLayout(false);
            panInfo.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panPrincipal;
        private Button btnConfirmar;
        private Button btnAtras;
        private Panel panInfo;
        private Panel panel2;
        private Panel panel1;
        private TextBox txtNombre;
        private Label label1;
        private TextBox txtDetalle;
        private Label label6;
        private TextBox txtPuerta;
        private Label label5;
        private TextBox txtCalle2;
        private Label label4;
        private TextBox txtCalle;
        private Label label3;
        private TextBox txtTelefono;
        private Label label2;
        private Panel panProductos;
        private Label lblPrecioTotal;
        private Label label7;
    }
}
