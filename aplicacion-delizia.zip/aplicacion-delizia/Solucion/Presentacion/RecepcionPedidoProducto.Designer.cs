﻿namespace Presentacion
{
    partial class RecepcionPedidoProducto
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblNombre = new Label();
            lblCantidad = new Label();
            lblPrecio = new Label();
            SuspendLayout();
            // 
            // lblNombre
            // 
            lblNombre.AutoSize = true;
            lblNombre.Location = new Point(3, 3);
            lblNombre.Name = "lblNombre";
            lblNombre.Size = new Size(38, 15);
            lblNombre.TabIndex = 0;
            lblNombre.Text = "label1";
            // 
            // lblCantidad
            // 
            lblCantidad.AutoSize = true;
            lblCantidad.Location = new Point(233, 3);
            lblCantidad.Name = "lblCantidad";
            lblCantidad.Size = new Size(38, 15);
            lblCantidad.TabIndex = 1;
            lblCantidad.Text = "label2";
            // 
            // lblPrecio
            // 
            lblPrecio.AutoSize = true;
            lblPrecio.Location = new Point(277, 3);
            lblPrecio.Name = "lblPrecio";
            lblPrecio.Size = new Size(38, 15);
            lblPrecio.TabIndex = 2;
            lblPrecio.Text = "label3";
            // 
            // RecepcionPedidoProducto
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(lblPrecio);
            Controls.Add(lblCantidad);
            Controls.Add(lblNombre);
            Name = "RecepcionPedidoProducto";
            Size = new Size(325, 20);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblNombre;
        private Label lblCantidad;
        private Label lblPrecio;
    }
}
