﻿namespace Presentacion
{
    partial class Login
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panPrincipal = new Panel();
            txtContrasena = new TextBox();
            txtCedula = new TextBox();
            lblContrasena = new Label();
            lblCedula = new Label();
            btnEntrar = new Button();
            btnBorrar = new Button();
            panPrincipal.SuspendLayout();
            SuspendLayout();
            // 
            // panPrincipal
            // 
            panPrincipal.Controls.Add(txtContrasena);
            panPrincipal.Controls.Add(txtCedula);
            panPrincipal.Controls.Add(lblContrasena);
            panPrincipal.Controls.Add(lblCedula);
            panPrincipal.Controls.Add(btnEntrar);
            panPrincipal.Controls.Add(btnBorrar);
            panPrincipal.Location = new Point(10, 10);
            panPrincipal.Name = "panPrincipal";
            panPrincipal.Size = new Size(780, 380);
            panPrincipal.TabIndex = 0;
            // 
            // txtContrasena
            // 
            txtContrasena.Location = new Point(10, 72);
            txtContrasena.Name = "txtContrasena";
            txtContrasena.Size = new Size(100, 23);
            txtContrasena.TabIndex = 5;
            // 
            // txtCedula
            // 
            txtCedula.Location = new Point(10, 28);
            txtCedula.Name = "txtCedula";
            txtCedula.Size = new Size(100, 23);
            txtCedula.TabIndex = 4;
            // 
            // lblContrasena
            // 
            lblContrasena.AutoSize = true;
            lblContrasena.Location = new Point(10, 54);
            lblContrasena.Name = "lblContrasena";
            lblContrasena.Size = new Size(67, 15);
            lblContrasena.TabIndex = 3;
            lblContrasena.Text = "Contraseña";
            // 
            // lblCedula
            // 
            lblCedula.AutoSize = true;
            lblCedula.Location = new Point(10, 10);
            lblCedula.Name = "lblCedula";
            lblCedula.Size = new Size(44, 15);
            lblCedula.TabIndex = 2;
            lblCedula.Text = "Cédula";
            // 
            // btnEntrar
            // 
            btnEntrar.Location = new Point(91, 101);
            btnEntrar.Name = "btnEntrar";
            btnEntrar.Size = new Size(75, 23);
            btnEntrar.TabIndex = 1;
            btnEntrar.Text = "Entrar";
            btnEntrar.UseVisualStyleBackColor = true;
            btnEntrar.Click += btnEntrar_Click;
            // 
            // btnBorrar
            // 
            btnBorrar.Location = new Point(10, 101);
            btnBorrar.Name = "btnBorrar";
            btnBorrar.Size = new Size(75, 23);
            btnBorrar.TabIndex = 0;
            btnBorrar.Text = "Borrar";
            btnBorrar.UseVisualStyleBackColor = true;
            btnBorrar.Click += btnBorrar_Click;
            // 
            // Login
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(panPrincipal);
            Name = "Login";
            Size = new Size(800, 400);
            panPrincipal.ResumeLayout(false);
            panPrincipal.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panPrincipal;
        private TextBox txtContrasena;
        private TextBox txtCedula;
        private Label lblContrasena;
        private Label lblCedula;
        private Button btnEntrar;
        private Button btnBorrar;
    }
}
