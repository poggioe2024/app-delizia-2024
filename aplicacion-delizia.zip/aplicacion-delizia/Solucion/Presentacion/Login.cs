﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Logica;

namespace Presentacion
{
    public partial class Login : UserControl
    {
        private Ventana parent;
        private LLogin logica = new LLogin();
        public Login(Ventana parent)
        {
            InitializeComponent();
            this.parent = parent;
        }

        private void btnEntrar_Click(object sender, EventArgs e)
        {
            string Cedula = txtCedula.Text;
            string Contrasena = txtContrasena.Text;

            if (Cedula != string.Empty && Contrasena != string.Empty)
            {
                int tipoUsuario;
                try
                {
                    tipoUsuario = logica.VerificarUsuario(Cedula, Contrasena);
                }
                catch (Exception ex) {
                    tipoUsuario = -1;
                }
                
                switch (tipoUsuario)
                {
                    case 1:
                        logica.InsertarLog(Cedula);
                        parent.Limpiar();
                        parent.Controls.Add(new RecepcionMenu(parent));
                        break;
                    case 2:
                        break;
                    case 3:
                        break;
                    case 4:
                        break;
                    case 0:
                        MessageBox.Show("Usuario inhabilitado. Por favor consulte con su supervisor e intente de nuevo.", "ERROR");
                        break;
                    default:
                        MessageBox.Show("Usuario o contraseña incorrectos. Por favor revise e intente de nuevo.", "ERROR");
                        break;
                }
            }
            else
            {
                MessageBox.Show("Existen campos sin completar. Por favor revise e intente de nuevo.","ERROR");
            }
        }

        private void btnBorrar_Click(object sender, EventArgs e)
        {
            txtCedula.Text = string.Empty;
            txtContrasena.Text = string.Empty;
        }
    }
}
