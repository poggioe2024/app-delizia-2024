﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using Logica;

namespace Presentacion
{
    public partial class RecepcionConfirmacion : UserControl
    {
        private Ventana parent;
        private RecepcionSeleccion recepcionSeleccion;
        private List<RecepcionProducto> Productos;
        private List<RecepcionPedidoProducto> productos = new List<RecepcionPedidoProducto>();
        public RecepcionConfirmacion(Ventana parent, RecepcionSeleccion recepcionSeleccion, List<RecepcionProducto> productosp)
        {
            InitializeComponent();
            this.parent = parent;
            this.recepcionSeleccion = recepcionSeleccion;
            this.Productos = productosp;
            MostrarProductos();
        }

        private void MostrarProductos() {
            double precioTotal = 0;
            foreach (RecepcionProducto p in Productos)
            {
                if (p.cantidad > 0)
                {
                    RecepcionPedidoProducto producto = new RecepcionPedidoProducto(p.Producto, p.cantidad);
                    productos.Add(producto);
                    precioTotal += p.Producto.Precio;
                }
            }
            int x = 10;
            int y = 10;
            foreach (RecepcionPedidoProducto p in productos)
            {
                panProductos.Controls.Add(p);
                p.Location = new Point(x, y);
                y += 25;
            }
            lblPrecioTotal.Text += precioTotal;
        }

        private void btnAtras_Click(object sender, EventArgs e)
        {
        }

        private void btnConfirmar_Click(object sender, EventArgs e)
        {
            // verifica que todos los campos obligatorios estén completos
            if (txtNombre.Text == string.Empty || txtTelefono.Text == string.Empty || txtCalle.Text == string.Empty || txtCalle2.Text == string.Empty)
            {
                MessageBox.Show("Por favor verifique que todos los datos están completos.", "ERROR");
            }
            else { 
                try
                {
                    string nombre = txtNombre.Text;
                    string telefono = txtTelefono.Text;
                    string calle1 = txtCalle.Text;
                    string calle2 = txtCalle2.Text;
                    int puerta = int.Parse(txtPuerta.Text);
                    string detalle = txtDetalle.Text;
                    List<Producto> productos = new List<Producto>();
                    foreach (RecepcionProducto p in Productos)
                    {
                        if (p.cantidad > 0) {
                            Producto producto = p.Producto;
                            producto.cantidad = p.cantidad;
                            productos.Add(producto);
                        }
                    }
                    parent.Limpiar();
                    parent.Controls.Add(new RecepcionMenu(parent));
                }
                catch (Exception ex) {
                    MessageBox.Show("Uno de los datos ingresados es incorrecto.", "ERROR");
                }
            }
            // enviar pedido
        }

        private void btnAtras_Click_1(object sender, EventArgs e)
        {
            parent.Limpiar();
            parent.Controls.Add(recepcionSeleccion);
        }
    }
}
