﻿namespace Presentacion
{
    partial class RecepcionMenu
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panPrincipal = new Panel();
            btnNuevoPedido = new Button();
            btnSalir = new Button();
            panPrincipal.SuspendLayout();
            SuspendLayout();
            // 
            // panPrincipal
            // 
            panPrincipal.Controls.Add(btnSalir);
            panPrincipal.Controls.Add(btnNuevoPedido);
            panPrincipal.Location = new Point(10, 10);
            panPrincipal.Name = "panPrincipal";
            panPrincipal.Size = new Size(780, 380);
            panPrincipal.TabIndex = 0;
            // 
            // btnNuevoPedido
            // 
            btnNuevoPedido.Location = new Point(10, 10);
            btnNuevoPedido.Name = "btnNuevoPedido";
            btnNuevoPedido.Size = new Size(75, 23);
            btnNuevoPedido.TabIndex = 0;
            btnNuevoPedido.Text = "Nuevo pedido";
            btnNuevoPedido.UseVisualStyleBackColor = true;
            btnNuevoPedido.Click += btnNuevoPedido_Click;
            // 
            // btnSalir
            // 
            btnSalir.Location = new Point(10, 39);
            btnSalir.Name = "btnSalir";
            btnSalir.Size = new Size(75, 23);
            btnSalir.TabIndex = 1;
            btnSalir.Text = "Salir";
            btnSalir.UseVisualStyleBackColor = true;
            btnSalir.Click += btnSalir_Click;
            // 
            // RecepcionMenu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(panPrincipal);
            Name = "RecepcionMenu";
            Size = new Size(800, 400);
            panPrincipal.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel panPrincipal;
        private Button btnSalir;
        private Button btnNuevoPedido;
    }
}
