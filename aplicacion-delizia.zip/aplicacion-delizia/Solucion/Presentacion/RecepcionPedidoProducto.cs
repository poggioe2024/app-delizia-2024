﻿using Logica;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentacion
{
    public partial class RecepcionPedidoProducto : UserControl
    {
        private int Cantidad;
        private Producto Producto;
        public RecepcionPedidoProducto(Producto producto, int cantidad)
        {
            InitializeComponent();
            this.Producto = producto;
            this.Cantidad = cantidad;

            lblCantidad.Text = "" + Cantidad;
            lblNombre.Text = "" + Producto.Nombre;
            lblPrecio.Text = "$" + Producto.Precio;
        }
    }
}
