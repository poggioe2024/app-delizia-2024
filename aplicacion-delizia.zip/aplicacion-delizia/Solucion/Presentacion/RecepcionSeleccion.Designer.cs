﻿namespace Presentacion
{
    partial class RecepcionSeleccion
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panPrincipal = new Panel();
            btnSiguiente = new Button();
            btnCancelar = new Button();
            panProductos = new Panel();
            panPrincipal.SuspendLayout();
            SuspendLayout();
            // 
            // panPrincipal
            // 
            panPrincipal.Controls.Add(btnSiguiente);
            panPrincipal.Controls.Add(btnCancelar);
            panPrincipal.Controls.Add(panProductos);
            panPrincipal.Location = new Point(10, 10);
            panPrincipal.Name = "panPrincipal";
            panPrincipal.Size = new Size(780, 380);
            panPrincipal.TabIndex = 0;
            // 
            // btnSiguiente
            // 
            btnSiguiente.Location = new Point(700, 350);
            btnSiguiente.Name = "btnSiguiente";
            btnSiguiente.Size = new Size(75, 23);
            btnSiguiente.TabIndex = 2;
            btnSiguiente.Text = "Siguiente";
            btnSiguiente.UseVisualStyleBackColor = true;
            btnSiguiente.Click += btnSiguiente_Click;
            // 
            // btnCancelar
            // 
            btnCancelar.Location = new Point(5, 350);
            btnCancelar.Name = "btnCancelar";
            btnCancelar.Size = new Size(75, 23);
            btnCancelar.TabIndex = 1;
            btnCancelar.Text = "Cancelar";
            btnCancelar.UseVisualStyleBackColor = true;
            btnCancelar.Click += btnCancelar_Click;
            // 
            // panProductos
            // 
            panProductos.AutoScroll = true;
            panProductos.Location = new Point(5, 5);
            panProductos.Name = "panProductos";
            panProductos.Size = new Size(770, 330);
            panProductos.TabIndex = 0;
            // 
            // RecepcionSeleccion
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(panPrincipal);
            Name = "RecepcionSeleccion";
            Size = new Size(800, 400);
            panPrincipal.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel panPrincipal;
        private Panel panProductos;
        private Button btnSiguiente;
        private Button btnCancelar;
    }
}
