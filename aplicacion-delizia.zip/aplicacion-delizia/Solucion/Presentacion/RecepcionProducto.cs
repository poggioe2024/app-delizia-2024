﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Logica;

namespace Presentacion
{
    public partial class RecepcionProducto : UserControl
    {
        public int cantidad;
        public Producto Producto;
        public RecepcionProducto(Producto producto)
        {
            InitializeComponent();
            cantidad = 0;
            Producto = producto;
            MostrarDatos();
        }

        private void MostrarDatos() {
            lblId.Text = "" + Producto.Id;
            lblNombre.Text = "" + Producto.Nombre;
            lblPrecio.Text = "$" + Producto.Precio;
        }

        private void btnRestar_Click(object sender, EventArgs e)
        {
            if (cantidad != 0) {
                cantidad--;
                lblCantidad.Text = "" + cantidad;
            }
        }

        private void btnSumar_Click(object sender, EventArgs e)
        {
            cantidad++;
            lblCantidad.Text = "" + cantidad;
        }
    }
}
