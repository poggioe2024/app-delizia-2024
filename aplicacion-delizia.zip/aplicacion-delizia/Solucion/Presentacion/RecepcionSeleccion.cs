﻿using Logica;
using Org.BouncyCastle.Pkcs;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentacion
{
    public partial class RecepcionSeleccion : UserControl
    {
        private Ventana parent;
        private List<RecepcionProducto> Productos;
        public RecepcionSeleccion(Ventana parent)
        {
            InitializeComponent();
            this.parent = parent;

            MostrarProductos();
        }

        private void MostrarProductos()
        {
            if (Productos != null)
            {
                Productos.Clear(); // Limpia la lista de productos
            }
            Productos = new List<RecepcionProducto>();

            LRecepcion logica = new LRecepcion();
            List<Producto> productos = logica.ConsultarProductos();

            int x = 10;
            int y = 10;
            int contador = 1;

            foreach (Producto producto in productos)
            {
                RecepcionProducto Producto = new RecepcionProducto(producto);
                Producto.Location = new Point(x, y);
                if (contador % 2 == 0)
                {
                    x = 10;
                    y += 190;
                }
                else
                {
                    x += 370;
                }
                panProductos.Controls.Add(Producto);
                this.Productos.Add(Producto);
                contador++;
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            parent.Limpiar();
            parent.Controls.Add(new RecepcionMenu(parent));
        }

        private void btnSiguiente_Click(object sender, EventArgs e)
        {
            parent.Limpiar();
            parent.Controls.Add(new RecepcionConfirmacion(parent, this, Productos));
        }
    }
}
