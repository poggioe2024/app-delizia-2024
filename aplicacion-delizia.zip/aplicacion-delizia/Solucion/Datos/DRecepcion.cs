﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos
{
    public class DRecepcion
    {
        public List<List<string>> Consultar(string Consulta)
        {
            Conexion Conexion = new Conexion();
            return Conexion.Consultar(Consulta);
        }
        public void Insertar(string Consulta)
        {
            Conexion Conexion = new Conexion();
            Conexion.Modificar(Consulta);
        }
    }
}
