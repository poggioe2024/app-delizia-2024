﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos
{
    public class DCrud
    {
        public String Tabla = "";
        public String[] Datos = new String[] { };
        public String[] DatosRel = new String[] { };
        public int TipoConsulta = 0;

        // En caso de editar
        public string Sujeto = "";
        public string SujetoRel = "";

        public String GenerarConsulta(DCrud Crud)
        {
            String Salida = "";
            switch (TipoConsulta)
            {
                case 1: // Insertar datos
                    Salida += "INSERT INTO " + Tabla + " ";
                    for (int i = 0; i < Datos.Length; i ++)
                    {
                        if (i == 0)
                        {
                            Salida += "(";
                        }
                        if (i == Datos.Length - 1)
                        {
                            Salida += Datos[i];
                            Salida += ")";
                        }
                        else
                        {
                            Salida += Datos[i] + ", ";
                        }
                    }
                    Salida += " VALUES ";
                    for (int i = 0; i < DatosRel.Length; i++)
                    {
                        if (i == 0)
                        {
                            Salida += "(";
                        }
                        if (i == DatosRel.Length - 1)
                        {
                            Salida += "'" + DatosRel[i] + "'";
                            Salida += ");";
                        }
                        else
                        {
                            Salida += "'" + DatosRel[i] + "', ";
                        }
                    }
                    break;
                case 2: // Eliminar datos
                    Salida += "DELETE FROM " + Tabla + " WHERE " + Sujeto + "='" + SujetoRel + "';";
                    break;
                case 3: // Editar datos
                    Salida += "UPDATE " + Tabla + " SET ";
                    for (int i = 0; i < Datos.Length; i++)
                    {
                        if (i == Datos.Length - 1)
                        {
                            Salida += Datos[i] + "='" + DatosRel[i] + "'";
                        }
                        else
                        {
                            Salida += Datos[i] + "='" + DatosRel[i] + "', ";
                        }
                    }
                    Salida += " WHERE " + Sujeto + "='" + SujetoRel + "';";
                    break;
                case 4: // Mostrar datos específicos
                    Salida += "SELECT ";
                    for (int i = 0; i < Datos.Length; i++)
                    {
                        if (i == Datos.Length - 1)
                        {
                            Salida += Datos[i];
                        }
                        else
                        {
                            Salida += Datos[i] + ", ";
                        }
                    }
                    Salida += " FROM " + Tabla + " WHERE " + Sujeto + "='" + SujetoRel + "';";
                    break;
                case 5: // Mostrar todos los datos
                    Salida += "SELECT ";
                    for (int i = 0; i < Datos.Length; i++)
                    {
                        if (i == Datos.Length - 1)
                        {
                            Salida += Datos[i];
                        }
                        else
                        {
                            Salida += Datos[i] + ", ";
                        }
                    }
                    Salida += " FROM " + Tabla + ";";
                    break;
                default:
                    Salida = "ERROR";
                    break;
            }
            return Salida;
        }
    }
}