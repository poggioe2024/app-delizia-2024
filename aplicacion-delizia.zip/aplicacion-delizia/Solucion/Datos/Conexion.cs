﻿using MySql.Data.MySqlClient;

namespace Datos
{
    public class Conexion
    {
        private MySqlConnection conexion;
        private string server = "localhost";
        private string database = "base_delizia";
        private string user = "admin-user";
        private string password = "k9Ph4W8/3pG-yn5H";
        private string cadena_conexion;

        public Conexion()
        {
            cadena_conexion = "Database=" + database +
                "; DataSource=" + server +
                "; User Id=" + user +
                "; Password=" + password;
        }

        public MySqlConnection Abrir()
        {
            if (conexion == null)
            {
                conexion = new MySqlConnection(cadena_conexion);
                conexion.Open();
            }
            return conexion;
        }
        public List<List<string>> Consultar(string consulta)
        {
            Abrir();
            List<List<string>> resultados = new List<List<string>>();
            MySqlDataReader mySqlDataReader = null;

            if (conexion != null)
            {
                MySqlCommand mySqlCommand = new MySqlCommand(consulta);
                mySqlCommand.Connection = Abrir();
                mySqlDataReader = mySqlCommand.ExecuteReader();

                while (mySqlDataReader.Read())
                {
                    List<string> valores_columnas = new List<string>();

                    for (int i = 0; i < mySqlDataReader.FieldCount; i++)
                    {
                        valores_columnas.Add(mySqlDataReader[i].ToString());
                    }

                    resultados.Add(valores_columnas);
                }

                mySqlDataReader.Close();
            }
            Cerrar();
            return resultados;
        }

        public void Modificar(string cadena)
        {
            Abrir();
            if (conexion != null)
            {
                MySqlCommand mySqlCommand = new MySqlCommand(cadena);
                mySqlCommand.Connection = Abrir();
                int filas_afectadas = mySqlCommand.ExecuteNonQuery();
            }
            Cerrar();
        }

        public void Cerrar()
        {
            if (conexion != null)
            {
                conexion.Close();
            }
        }
    }
}
