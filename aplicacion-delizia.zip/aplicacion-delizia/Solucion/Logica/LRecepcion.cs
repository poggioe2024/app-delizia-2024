﻿using Datos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logica
{
    public class LRecepcion
    {

        public List<Producto> ConsultarProductos() {
            DCrud Crud = new DCrud();
            Crud.Tabla = "productos";
            Crud.Datos = new String[] { "*" };
            Crud.TipoConsulta = 5;

            string ConsultaGenerada = Crud.GenerarConsulta(Crud); // Genera la consulta
            DRecepcion dRecepcion = new DRecepcion();
            return GenerarProductos(dRecepcion.Consultar(ConsultaGenerada));
        }

        private List<Producto> GenerarProductos(List<List<string>> productos) {
            List<Producto> Productos = new List<Producto>();
            foreach (List<string> p in productos) {
                Producto Producto = new Producto(int.Parse(p[0]), p[1], double.Parse(p[2]), int.Parse(p[3]));
                Productos.Add(Producto);
            }
            return Productos;
        }
    }
}
