﻿using Datos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logica
{
    public class LLogin
    {
        public int VerificarUsuario(string cedula, string contrasena)
        {
            DCrud Crud = new DCrud();
            Crud.Tabla = "funcionarios";
            Crud.Datos = new String[] { "Cedula", "Contrasena", "Activo", "Rol"};
            Crud.TipoConsulta = 4;
            Crud.Sujeto = "cedula";
            Crud.SujetoRel = cedula;

            string ConsultaGenerada = Crud.GenerarConsulta(Crud); // Genera la consulta
            List<string> usuario = ConsultarUsuario(ConsultaGenerada);

            bool activo = VerificarActividad(usuario);

            if (activo)
            {
                if (contrasena == usuario[1])
                {
                    return int.Parse(usuario[3]);
                }
                else
                {
                    return -1;
                }
            }
            else {
                return 0;
            }
        }

        private List<string> ConsultarUsuario(string consulta) {
            DLogin DLogin = new DLogin();
            List<string> salida = DLogin.Consultar(consulta)[0];
            return salida;
        }

        private bool VerificarActividad(List<string> usuario) {
            if (usuario[2] == "Si")
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public Funcionario ObtenerFuncionario(string cedula){
            Funcionario funcionario;
            DCrud Crud = new DCrud();
            Crud.Tabla = "funcionarios";
            Crud.Datos = new String[] { "Cedula", "Rol", "Nombre", "Apellido" };
            Crud.TipoConsulta = 4;
            Crud.Sujeto = "cedula";
            Crud.SujetoRel = cedula;

            string consulta = Crud.GenerarConsulta(Crud);

            DLogin DLogin = new DLogin();
            List<string> usr = DLogin.Consultar(consulta)[0];

            funcionario = new Funcionario(usr[0], int.Parse(usr[1]), usr[2], usr[3], null, null, null, null, 0, null);

            return funcionario;
        }

        public void InsertarLog(string cedula) {
            DCrud Crud = new DCrud();
            Crud.Tabla = "logs";
            Crud.Datos = new String[] { "Fecha", "Hora", "Funcionario", "Equipo" };

            string fecha = DateOnly.FromDateTime(DateTime.Now).ToString("yyyy-MM-dd");
            string hora = TimeOnly.FromDateTime(DateTime.Now).ToString("HH:mm:ss");
            string equipo = "" + Environment.MachineName;

            Crud.DatosRel = new string[] { fecha, hora, cedula, equipo};
            Crud.TipoConsulta = 1;

            string consulta = Crud.GenerarConsulta(Crud);

            DLogin DLogin = new DLogin();
            DLogin.Insertar(consulta);
        }
    }
}
