﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


// Programado por Elián Poggio
namespace Logica
{
    public class Funcionario
    {
        private string Cedula { get => Cedula; set => Cedula = value; }
        private int Rol { get => Rol; set => Rol = value; }
        private string Nombre { get => Nombre; set => Nombre = value; }
        private string Apellido { get => Apellido; set => Apellido = value; }
        private string Correo { get => Correo; set => Correo = value; }
        private String[] Telefonos { get => Telefonos; set => Telefonos = value; }
        private string Calle1 { get => Calle1; set => Calle1 = value; }
        private string Calle2 { get => Calle2; set => Calle2 = value; }
        private int Puerta { get => Puerta; set => Puerta = value; }
        private string Activo { get => Activo; set => Activo = value; }
        
        // Constructor de la clase
        public Funcionario(string cedula, int rol, string nombre, string apellido, string correo, string[] telefonos, string calle1, string calle2, int puerta, string activo)
        {
            Cedula = cedula;
            Rol = rol;
            Nombre = nombre;
            Apellido = apellido;
            Correo = correo;
            Telefonos = telefonos;
            Calle1 = calle1;
            Calle2 = calle2;
            Puerta = puerta;
            Activo = activo;
        }
    }
}
