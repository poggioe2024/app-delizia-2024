﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// Programado por Elián Poggio
namespace Logica
{
    public class Producto
    {
        public int Id;
        public string Nombre;
        public double Precio;
        public int Tipo;
        public int cantidad = 0;

        // Constructor de la clase
        public Producto(int id, string nombre, double precio, int tipo)
        {
            Id = id;
            Nombre = nombre;
            Precio = precio;
            Tipo = tipo;
        }
    }
}
