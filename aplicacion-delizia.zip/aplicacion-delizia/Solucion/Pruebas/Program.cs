﻿using Datos;
namespace Pruebas
{

    class Program
    {
        static void Main() {
            DCrud Crud = new DCrud();
            Crud.Tabla = "funcionario";
            Crud.Datos = new string[] {"Cedula", "Telefono"};
            Crud.DatosRel = new string[] { "1", "2", "juan", "12345", "no" };
            Crud.TipoConsulta = 3;
            Crud.Sujeto = "Cedula";
            Crud.SujetoRel = "12345";
            Crud.TipoConsulta = 4;
            Console.WriteLine("" + Crud.GenerarConsulta(Crud));
            Crud.TipoConsulta = 3;
            Console.WriteLine(""+Crud.GenerarConsulta(Crud));
            Crud.TipoConsulta = 2;
            Console.WriteLine("" + Crud.GenerarConsulta(Crud));
            Crud.TipoConsulta = 1;
            Console.WriteLine("" + Crud.GenerarConsulta(Crud));
            Crud.Tabla = "productos";
            Crud.Datos = new String[] { "*" };
            Crud.TipoConsulta = 5;

            string ConsultaGenerada = Crud.GenerarConsulta(Crud); // Genera la consulta
            Console.WriteLine(ConsultaGenerada);
        }
    }
    
}